# Routine_management_system
This is a web project that has been created for 5th semester in CSE department.

Step-1: If you are a student just click on the semester and click view routine then proceed. 
step-2: IF you are a teacher then login as a Teacher to view your personal routine.
step-3: If you are admin, click on the admin login and add id and password to log in and continue.
Step-4: Add Information, teachers, courses, course code, classroom, and other allotments.
step-5: click on the generate button to generate the schedule.
step-5: after completing you can see the schedules of every teacher.


TO INSTALL/RUN THIS PROGRAM{}
you need to install xampp, visual studio code(optional)
You just need to download this file to zip file, then with winrar/7zip/unzip application to unzip the zipped file.
From then you need to copy the whole file and from the installed file to the C-drive, go to the xampp in C-drive,
then on the htdocs folder, then create a file name with your preference(mine is phpscript).
copy all things to the phpscript folder, and then open xampp and run apache and MySQL.
Go to any web browser and type localhost/phpmyadmin then create a database named ttms.
On the ttms database click import and select the ttms.sql file from the phpscript folder. Then click ok/import to import the database.
then write down localhost/phpscript
then you can see and edit the whole project. It's easy and very simple as that.






!!!![ DISCLAIMER ]!!!!
THIS PROJECT IS CREATED FOR EDUCATION PURPOSE ONLY ITS NOT FOR RETAILATION OR FOR SELL.
THIS PROJECT IS CREATED BY THE 5TH SEMESTER, COMPUTER SCIENCE AND ENGINEERING STUDENT OF "BANGLADESH ARMY UNIVERSITY OF ENGINEERING AND TECHNOLOGY."
